import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import AdmZip from 'adm-zip';

import { loadLauncherState, normalizeProfile, saveLauncherState } from '../src/lib/launcherState.js';
import { cleanMinecraftVersion } from '../src/lib/modrinth.js';
import { createOfflineSession, formatFileSize, findModInList } from '../src/utils/formatters.js';
import {
  calculateSafeRamGb,
  compareVersionTuples,
  extractNativeLibraries,
  makeOfflineUuid,
  mergeVersionMetadata,
  resolveMinecraftVersion,
  splitCommandLine,
  stageModsForSafeMode,
  summarizeLaunchFailure,
  versionToTuple,
} from '../electron/services/minecraftRunner.js';
import {
  buildMavenArtifactInfo,
  installMinecraft,
  isValidJarFile,
  readInstalledVersions,
  runCommand,
  rulesPassForCurrentSystem,
} from '../electron/services/minecraftInstaller.js';
import { extractJarMetadata, normalizeModFileName, readInstalledMods, toggleMod } from '../electron/services/contentManager.js';
import { getInstanceDir } from '../electron/services/paths.js';
import { normalizeLoader, resolveInstalledVersionForInstance } from '../src/utils/versionSelection.js';
import { expandJavaExecutableCandidate, requiredJavaForMinecraft } from '../electron/services/javaDetector.js';

let checks = 0;
function check(name, callback) {
  callback();
  checks += 1;
  console.log(`✓ ${name}`);
}

async function checkAsync(name, callback) {
  await callback();
  checks += 1;
  console.log(`✓ ${name}`);
}

check('Minecraft and loader version parsing', () => {
  assert.equal(resolveMinecraftVersion('fabric-loader-0.16.10-1.21.4'), '1.21.4');
  assert.equal(cleanMinecraftVersion('Forge 54.0.1 - 1.21.4'), '1.21.4');
  assert.equal(resolveMinecraftVersion({ inheritsFrom: '1.21.11' }), '1.21.11');
});

check('Instances select only a compatible installed loader version', () => {
  const installed = [
    { id: '1.21.4', type: 'vanilla', mcVer: '1.21.4' },
    { id: 'fabric-loader-0.16.10-1.21.4', type: 'fabric', inheritsFrom: '1.21.4' },
    { id: 'neoforge-21.4.1', type: 'neoforge', mcVer: '1.21.4' },
  ];
  assert.equal(resolveInstalledVersionForInstance({ version: '1.21.4', loader: 'fabric' }, installed)?.id, 'fabric-loader-0.16.10-1.21.4');
  assert.equal(resolveInstalledVersionForInstance({ version: 'missing', loader: 'fabric' }, installed), null);
  assert.equal(normalizeLoader('NeoForge 21.4.1'), 'neoforge');
});

check('Java-compatible offline UUID generation', () => {
  assert.equal(makeOfflineUuid('Notch'), 'b50ad385-829d-3141-a216-7e7d7539ba7f');
  assert.deepEqual(createOfflineSession('Player'), { name: 'Player', username: 'Player', userType: 'legacy' });
});

check('Low-memory launch settings are clamped and failures are explained', () => {
  assert.equal(calculateSafeRamGb(8, 4 * 1024 ** 3), 2);
  assert.equal(calculateSafeRamGb(4, 16 * 1024 ** 3), 4);
  assert.match(summarizeLaunchFailure('Error occurred during initialization of VM\nCould not reserve enough space'), /Reduce the profile RAM/);
  assert.match(summarizeLaunchFailure('Incompatible mods found!'), /Mods tab/);
  assert.equal(
    summarizeLaunchFailure('java.lang.RuntimeException: launch failed\nCaused by: java.nio.file.AccessDeniedException: options.txt\n\t... 1 more'),
    'java.nio.file.AccessDeniedException: options.txt',
  );
});

check('Java paths and modern Minecraft requirements are normalized', () => {
  assert.equal(expandJavaExecutableCandidate('"/opt/java/bin/java"')[0], '/opt/java/bin/java');
  assert.equal(requiredJavaForMinecraft('1.21.4'), 21);
  assert.equal(requiredJavaForMinecraft('1.20.1'), 17);
});

await checkAsync('Missing Java spawn reports an actionable installer error', async () => {
  await assert.rejects(
    runCommand('/definitely-missing-blazzy-java', ['-version']),
    /Java executable was not found/,
  );
});

check('Quoted JVM and legacy game arguments', () => {
  assert.deepEqual(splitCommandLine('-Xmx4G -Dname="Blazzy Client" --path "C:\\Game Files\\MC"'), [
    '-Xmx4G', '-Dname=Blazzy Client', '--path', 'C:\\Game Files\\MC',
  ]);
  assert.deepEqual(splitCommandLine("--username 'Apple Skin'"), ['--username', 'Apple Skin']);
});

check('Child metadata overrides inherited libraries', () => {
  const merged = mergeVersionMetadata(
    { libraries: [{ name: 'base:one:1' }], arguments: { game: ['--base'] }, mainClass: 'Base' },
    { libraries: [{ name: 'child:two:2' }], arguments: { game: ['--child'] }, mainClass: 'Child' },
  );
  assert.deepEqual(merged.libraries.map(item => item.name), ['base:one:1', 'child:two:2']);
  assert.deepEqual(merged.arguments.game, ['--base', '--child']);
  assert.equal(merged.mainClass, 'Child');
  assert.equal(compareVersionTuples(versionToTuple('1.10.0'), versionToTuple('1.9.9')), 1);
});

check('Maven coordinates and platform rules', () => {
  assert.equal(buildMavenArtifactInfo('org.lwjgl:lwjgl:3.3.3:natives-windows').relativePath,
    'org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-windows.jar');
  assert.equal(rulesPassForCurrentSystem([{ action: 'allow', os: { name: process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux' } }]), true);
  assert.equal(rulesPassForCurrentSystem([{ action: 'allow', features: { demo_user: true } }], { demo_user: false }), false);
});

check('Path traversal is rejected for instances and imported names', () => {
  assert.throws(() => getInstanceDir('../outside'), /Invalid instance/);
  assert.equal(normalizeModFileName('../../sodium.jar'), 'sodium.jar');
});

check('Formatting and installed-mod matching helpers', () => {
  assert.equal(formatFileSize(1536), '1.5 KB');
  assert.equal(findModInList([{ fileName: 'sodium-fabric-0.6.0.jar', modId: 'sodium' }], 'sodium')?.modId, 'sodium');
});

await checkAsync('State persistence, normalization, and backup recovery', async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'blazzy-state-'));
  try {
    const profile = normalizeProfile({ id: 'p1', name: '   ', ram: 999 }, 0);
    assert.equal(profile.name, 'Default');
    assert.equal(profile.ram, 128);
    await saveLauncherState(dir, { profiles: [profile], activeProfileId: 'p1', settings: { launchBehavior: 'close' } });
    await saveLauncherState(dir, { profiles: [{ ...profile, name: 'Recovered' }], activeProfileId: 'p1', settings: { launchBehavior: 'hide' } });
    await fsp.writeFile(path.join(dir, 'launcher-state.json'), '{broken', 'utf8');
    const recovered = await loadLauncherState(dir);
    assert.equal(recovered.profiles[0].name, 'Default');
    assert.equal(recovered.settings.launchBehavior, 'close');
  } finally {
    await fsp.rm(dir, { recursive: true, force: true });
  }
});

await checkAsync('JAR validation, metadata reading, and safe native extraction', async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'blazzy-native-'));
  try {
    const jarPath = path.join(dir, 'example.jar');
    const zip = new AdmZip();
    zip.addFile('fabric.mod.json', Buffer.from(JSON.stringify({ id: 'apple-skin', name: 'Apple Skin', version: '1.0.0' })));
    zip.addFile('native/test-native.dll', Buffer.from('native'));
    zip.addFile('META-INF/signature.SF', Buffer.from('ignored'));
    zip.writeZip(jarPath);
    assert.equal(isValidJarFile(jarPath), true);
    assert.equal(extractJarMetadata(jarPath)?.displayName, 'Apple Skin');
    const nativeDir = path.join(dir, 'natives');
    await extractNativeLibraries([{ path: jarPath, exclude: ['fabric.mod.json'] }], nativeDir);
    assert.equal(fs.existsSync(path.join(nativeDir, 'native', 'test-native.dll')), true);
    assert.equal(fs.existsSync(path.join(nativeDir, 'META-INF', 'signature.SF')), false);
  } finally {
    await fsp.rm(dir, { recursive: true, force: true });
  }
});

await checkAsync('Installed versions come from complete launchable folders only', async () => {
  const minecraftRoot = '/tmp/blazzy-client-test-home/.minecraft';
  const versionsDir = path.join(minecraftRoot, 'versions');
  await fsp.rm(minecraftRoot, { recursive: true, force: true });
  try {
    const baseDir = path.join(versionsDir, '1.21.4');
    const fabricId = 'fabric-loader-0.16.10-1.21.4';
    const fabricDir = path.join(versionsDir, fabricId);
    const staleDir = path.join(versionsDir, 'stale-version');
    await Promise.all([baseDir, fabricDir, staleDir].map(dir => fsp.mkdir(dir, { recursive: true })));

    const clientJar = new AdmZip();
    clientJar.addFile('net/minecraft/client/Main.class', Buffer.from('client'));
    clientJar.writeZip(path.join(baseDir, '1.21.4.jar'));
    await fsp.writeFile(path.join(baseDir, '1.21.4.json'), JSON.stringify({ id: '1.21.4', type: 'vanilla', mainClass: 'net.minecraft.client.Main' }));
    await fsp.writeFile(path.join(fabricDir, `${fabricId}.json`), JSON.stringify({ id: fabricId, type: 'fabric', inheritsFrom: '1.21.4', mainClass: 'net.fabricmc.loader.impl.launch.knot.KnotClient' }));
    await fsp.writeFile(path.join(staleDir, 'stale-version.json'), JSON.stringify({ id: 'stale-version', type: 'vanilla' }));

    const versions = await readInstalledVersions();
    assert.equal(versions.some(version => version.id === '1.21.4'), true);
    assert.equal(versions.some(version => version.id === fabricId), true);
    assert.equal(versions.some(version => version.id === 'stale-version'), false);
  } finally {
    await fsp.rm(minecraftRoot, { recursive: true, force: true });
  }
});

await checkAsync('Fabric installation uses official profile data without spawning a Java installer', async () => {
  const minecraftRoot = '/tmp/blazzy-client-test-home/.minecraft';
  const originalFetch = globalThis.fetch;
  const requestedUrls = [];
  const clientJar = new AdmZip();
  clientJar.addFile('net/minecraft/client/Main.class', Buffer.from('client'));
  const clientBytes = clientJar.toBuffer();
  globalThis.fetch = async (input) => {
    const url = String(input);
    requestedUrls.push(url);
    if (url.includes('version_manifest_v2.json')) {
      return new Response(JSON.stringify({ versions: [{ id: '1.21.4', url: 'https://test.invalid/version.json' }] }), { status: 200 });
    }
    if (url.endsWith('/version.json')) {
      return new Response(JSON.stringify({
        id: '1.21.4',
        mainClass: 'net.minecraft.client.main.Main',
        downloads: { client: { url: 'https://test.invalid/client.jar' } },
        libraries: [],
      }), { status: 200 });
    }
    if (url.endsWith('/client.jar')) return new Response(clientBytes, { status: 200 });
    if (url.includes('/versions/loader/1.21.4/0.16.10/profile/json')) {
      return new Response(JSON.stringify({
        id: 'fabric-loader-0.16.10-1.21.4',
        inheritsFrom: '1.21.4',
        mainClass: 'net.fabricmc.loader.impl.launch.knot.KnotClient',
        libraries: [{ name: 'net.fabricmc:fabric-loader:0.16.10', url: 'https://maven.fabricmc.net/' }],
      }), { status: 200 });
    }
    return new Response('not found', { status: 404 });
  };
  await fsp.rm(minecraftRoot, { recursive: true, force: true });
  try {
    const result = await installMinecraft({ type: 'fabric', gameVersion: '1.21.4', loaderVersion: '0.16.10' });
    assert.equal(result.ok, true);
    assert.equal(result.id, 'fabric-loader-0.16.10-1.21.4');
    assert.equal(fs.existsSync(path.join(minecraftRoot, 'versions', result.id, `${result.id}.json`)), true);
    assert.equal(requestedUrls.some(url => url.includes('fabric-installer')), false);
  } finally {
    globalThis.fetch = originalFetch;
    await fsp.rm(minecraftRoot, { recursive: true, force: true });
  }
});

await checkAsync('Instance mod folders load and toggle common disabled files', async () => {
  const instanceId = 'test-instance';
  const modsDir = '/tmp/blazzy-client-test-home/.minecraft/instances/test-instance/mods';
  await fsp.rm(path.dirname(modsDir), { recursive: true, force: true });
  try {
    await fsp.mkdir(modsDir, { recursive: true });
    const disabledPath = path.join(modsDir, 'apple-skin.jar.disabled');
    const jar = new AdmZip();
    jar.addFile('fabric.mod.json', Buffer.from(JSON.stringify({ id: 'appleskin', name: 'AppleSkin', version: '3.0.6' })));
    jar.writeZip(disabledPath);
    const before = await readInstalledMods(instanceId);
    assert.equal(before[0]?.name, 'AppleSkin');
    assert.equal(before[0]?.enabled, false);
    assert.equal((await toggleMod(before[0].id, true, instanceId)).ok, true);
    assert.equal(fs.existsSync(path.join(modsDir, 'apple-skin.jar')), true);
  } finally {
    await fsp.rm(path.dirname(modsDir), { recursive: true, force: true });
  }
});

await checkAsync('Safe mode temporarily stages enabled mods and restores them', async () => {
  const gameDir = await fsp.mkdtemp(path.join(os.tmpdir(), 'blazzy-safe-mode-'));
  try {
    const modsDir = path.join(gameDir, 'mods');
    await fsp.mkdir(modsDir, { recursive: true });
    await fsp.writeFile(path.join(modsDir, 'broken-mod.jar'), 'test');
    await fsp.writeFile(path.join(modsDir, 'disabled.olpkg'), 'test');
    const restore = await stageModsForSafeMode(gameDir);
    assert.equal(fs.existsSync(path.join(modsDir, 'broken-mod.jar')), false);
    assert.equal(fs.existsSync(path.join(modsDir, 'disabled.olpkg')), true);
    await restore();
    assert.equal(fs.existsSync(path.join(modsDir, 'broken-mod.jar')), true);
  } finally {
    await fsp.rm(gameDir, { recursive: true, force: true });
  }
});

console.log(`\n${checks} core feature checks passed.`);
