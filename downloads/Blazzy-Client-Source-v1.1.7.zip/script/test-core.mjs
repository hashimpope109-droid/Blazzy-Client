import assert from 'node:assert/strict';
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import AdmZip from 'adm-zip';

import { loadLauncherState, normalizeProfile, saveLauncherState } from '../src/lib/launcherState.js';
import { cleanMinecraftVersion } from '../src/lib/modrinth.js';
import { createOfflineSession, formatFileSize, findModInList } from '../src/utils/formatters.js';
import {
  compareVersionTuples,
  extractNativeLibraries,
  makeOfflineUuid,
  mergeVersionMetadata,
  resolveMinecraftVersion,
  splitCommandLine,
  versionToTuple,
} from '../electron/services/minecraftRunner.js';
import {
  buildMavenArtifactInfo,
  isValidJarFile,
  rulesPassForCurrentSystem,
} from '../electron/services/minecraftInstaller.js';
import { extractJarMetadata, normalizeModFileName } from '../electron/services/contentManager.js';
import { getInstanceDir } from '../electron/services/paths.js';

let checks = 0;
function check(name, callback) {
  callback();
  checks += 1;
  console.log(`✓ ${name}`);
}

async function checkAsync(name, callback) {
  await callback();
  checks += 1;
  console.log(`✓ ${name}`);
}

check('Minecraft and loader version parsing', () => {
  assert.equal(resolveMinecraftVersion('fabric-loader-0.16.10-1.21.4'), '1.21.4');
  assert.equal(cleanMinecraftVersion('Forge 54.0.1 - 1.21.4'), '1.21.4');
  assert.equal(resolveMinecraftVersion({ inheritsFrom: '1.21.11' }), '1.21.11');
});

check('Java-compatible offline UUID generation', () => {
  assert.equal(makeOfflineUuid('Notch'), 'b50ad385-829d-3141-a216-7e7d7539ba7f');
  assert.deepEqual(createOfflineSession('Player'), { name: 'Player', username: 'Player', userType: 'legacy' });
});

check('Quoted JVM and legacy game arguments', () => {
  assert.deepEqual(splitCommandLine('-Xmx4G -Dname="Blazzy Client" --path "C:\\Game Files\\MC"'), [
    '-Xmx4G', '-Dname=Blazzy Client', '--path', 'C:\\Game Files\\MC',
  ]);
  assert.deepEqual(splitCommandLine("--username 'Apple Skin'"), ['--username', 'Apple Skin']);
});

check('Child metadata overrides inherited libraries', () => {
  const merged = mergeVersionMetadata(
    { libraries: [{ name: 'base:one:1' }], arguments: { game: ['--base'] }, mainClass: 'Base' },
    { libraries: [{ name: 'child:two:2' }], arguments: { game: ['--child'] }, mainClass: 'Child' },
  );
  assert.deepEqual(merged.libraries.map(item => item.name), ['base:one:1', 'child:two:2']);
  assert.deepEqual(merged.arguments.game, ['--base', '--child']);
  assert.equal(merged.mainClass, 'Child');
  assert.equal(compareVersionTuples(versionToTuple('1.10.0'), versionToTuple('1.9.9')), 1);
});

check('Maven coordinates and platform rules', () => {
  assert.equal(buildMavenArtifactInfo('org.lwjgl:lwjgl:3.3.3:natives-windows').relativePath,
    'org/lwjgl/lwjgl/3.3.3/lwjgl-3.3.3-natives-windows.jar');
  assert.equal(rulesPassForCurrentSystem([{ action: 'allow', os: { name: process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux' } }]), true);
  assert.equal(rulesPassForCurrentSystem([{ action: 'allow', features: { demo_user: true } }], { demo_user: false }), false);
});

check('Path traversal is rejected for instances and imported names', () => {
  assert.throws(() => getInstanceDir('../outside'), /Invalid instance/);
  assert.equal(normalizeModFileName('../../sodium.jar'), 'sodium.jar');
});

check('Formatting and installed-mod matching helpers', () => {
  assert.equal(formatFileSize(1536), '1.5 KB');
  assert.equal(findModInList([{ fileName: 'sodium-fabric-0.6.0.jar', modId: 'sodium' }], 'sodium')?.modId, 'sodium');
});

await checkAsync('State persistence, normalization, and backup recovery', async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'blazzy-state-'));
  try {
    const profile = normalizeProfile({ id: 'p1', name: '   ', ram: 999 }, 0);
    assert.equal(profile.name, 'Default');
    assert.equal(profile.ram, 128);
    await saveLauncherState(dir, { profiles: [profile], activeProfileId: 'p1', settings: { launchBehavior: 'close' } });
    await saveLauncherState(dir, { profiles: [{ ...profile, name: 'Recovered' }], activeProfileId: 'p1', settings: { launchBehavior: 'hide' } });
    await fsp.writeFile(path.join(dir, 'launcher-state.json'), '{broken', 'utf8');
    const recovered = await loadLauncherState(dir);
    assert.equal(recovered.profiles[0].name, 'Default');
    assert.equal(recovered.settings.launchBehavior, 'close');
  } finally {
    await fsp.rm(dir, { recursive: true, force: true });
  }
});

await checkAsync('JAR validation, metadata reading, and safe native extraction', async () => {
  const dir = await fsp.mkdtemp(path.join(os.tmpdir(), 'blazzy-native-'));
  try {
    const jarPath = path.join(dir, 'example.jar');
    const zip = new AdmZip();
    zip.addFile('fabric.mod.json', Buffer.from(JSON.stringify({ id: 'apple-skin', name: 'Apple Skin', version: '1.0.0' })));
    zip.addFile('native/test-native.dll', Buffer.from('native'));
    zip.addFile('META-INF/signature.SF', Buffer.from('ignored'));
    zip.writeZip(jarPath);
    assert.equal(isValidJarFile(jarPath), true);
    assert.equal(extractJarMetadata(jarPath)?.displayName, 'Apple Skin');
    const nativeDir = path.join(dir, 'natives');
    await extractNativeLibraries([{ path: jarPath, exclude: ['fabric.mod.json'] }], nativeDir);
    assert.equal(fs.existsSync(path.join(nativeDir, 'native', 'test-native.dll')), true);
    assert.equal(fs.existsSync(path.join(nativeDir, 'META-INF', 'signature.SF')), false);
  } finally {
    await fsp.rm(dir, { recursive: true, force: true });
  }
});

console.log(`\n${checks} core feature checks passed.`);
